--     ___                   _          ____        __                  
--    /   |____  __  _______(_)___ _   / __ )____ _/ /_____  _______  __
--   / /| /_  / / / / / ___/ / __ `/  / __  / __ `/ //_/ _ \/ ___/ / / /
--  / ___ |/ /_/ /_/ / /  / / /_/ /  / /_/ / /_/ / ,< /  __/ /  / /_/ / 
-- /_/  |_/___/\__,_/_/  /_/\__,_/  /_____/\__,_/_/|_|\___/_/   \__, /  
--                                                             /____/   


AzuriaBakery = AzuriaBakery or {}

AzuriaBakery.UseHungerMod = true // Mettre true si vous désirez utiliser hungermod, mettre false si vous désirez utiliser la vie du joueur
AzuriaBakery.AmmToAdd = 10 // Quantité de vie / faim a ajouter
AzuriaBakery.CookTime = 2 //Temps de cuisson du pain
AzuriaBakery.CookColor = Color(255,0,0) // Couleur lors de la cuisson (Temporaire)

// Noter que le script qui est publié est mon premier, pour l'instant certains fonctionnalités sont en dévloppement, ce script serra améliorer avec le temps
