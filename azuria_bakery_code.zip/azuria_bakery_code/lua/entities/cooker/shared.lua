ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Cooker"
ENT.Spawnable = true 
ENT.AdminOnly = true 
ENT.Category = "Azuria - Bakery"