ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Dough"
ENT.Spawnable = true 
ENT.AdminOnly = true 
ENT.Category = "Azuria - Bakery"