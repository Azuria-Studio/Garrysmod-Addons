ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Bread"
ENT.Spawnable = true 
ENT.AdminOnly = true 
ENT.Category = "Azuria - Bakery" 