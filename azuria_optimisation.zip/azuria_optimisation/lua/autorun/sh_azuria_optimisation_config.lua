AzuriaOpti = AzuriaOpti or {}

/*
-----------------------------------------------------------
Optimisation client
-----------------------------------------------------------
*/    
       
AzuriaOpti.CLActive = false // Activer ou desactiver le script Client